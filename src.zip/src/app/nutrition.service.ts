import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class NutritionService {
  public url;
  public url1;
  constructor(private http: HttpClient) {
  }
  getCal(item) {
    // this.url1 = 'https://stream.watsonplatform.net/text-to-speech/api/v1/synthesize?username=f61d1286-72ec-4d67-a0a2-16969a62acac&password=4AmGC8jSSy5G&text=' + item + '';
    this.url = 'https://api.nutritionix.com/v1_1/search/' + item + '?' + 'results=0:1&fields=*&appId=d30da655&appKey=b86c2cb215fc15f9512f44c3c959acd4';
    // this.url = 'http://api.wunderground.com/api/4bbbc25f4f5946dd/conditions/q/' + code + '/' + city + '.json';
    return this.http.get(this.url);
  }
}

