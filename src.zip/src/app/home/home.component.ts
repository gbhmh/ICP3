import { Component, OnInit } from '@angular/core';
import { NutritionService } from '../nutrition.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [ NutritionService ]
})
export class HomeComponent implements OnInit {
  item: string;
  public loc1: any;
  public url1: any;
  public  value10: any;
  public  value12: any;

  constructor(
    private foodcal: NutritionService,
    private router: Router  ) { }
  ngOnInit() {
    // this.Weather = response;
  }
  Search() {

    this.loc1 = {
      item: this.item
    };
    this.foodcal.getCal(this.loc1.item).subscribe(response => {
      console.log(response);
      this.value10 = response;
    });
    this.url1 = 'https://stream.watsonplatform.net/text-to-speech/api/v1/synthesize?username=f61d1286-72ec-4d67-a0a2-16969a62acac&password=4AmGC8jSSy5G&text=' + this.item + '';
  }
  Logout() {
    this.router.navigateByUrl('/Login');
  }
}
