import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  user: string;
  pass: string;
  confpass: string;
  public loc3: any;
  public res: any;
  constructor(
    private router: Router
  ) { }

  ngOnInit() {
  }
  Show() {

    this.loc3 = {
      user: this.user,
      pass: this.pass,
      confpass: this.confpass
    };
    // localStorage.setItem( key: 'loc');
    if (this.pass === this.confpass) {
      localStorage.clear();
      localStorage.setItem('username', this.user) ;
      localStorage.setItem('password', this.pass) ;
      alert('User Successfully registered');
      this.res = 'User Successfully registered';
      this.router.navigateByUrl('/Login');
    } else {
      alert('Password and Confirm Password fields are not matching');
    }
  }
}
