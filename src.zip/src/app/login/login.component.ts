import { Component, OnInit } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  user: string;
  pass: string;
  title = 'Food Calories'
  public loc2: any;
  public value1: any;
  public value2: any;
  public value3: any;
  constructor(private router: Router) { }

  ngOnInit() {
  }
  Show() {

    this.loc2 = {
      user: this.user,
      pass: this.pass
    };
    this.value1 = (localStorage.getItem('username'));
    this.value2 = (localStorage.getItem('password'));
    if (this.user === this.value1 && this.pass === this.value2) {
      this.router.navigateByUrl('/Home');
    } else {
      alert('Wrong Credentials');
    }
    // localStorage.setItem( key: 'loc');
    // localStorage.clear();
    // localStorage.setItem('credentials', JSON.stringify(this.loc));
    // localStorage.setItem('username', this.user) ;
    // localStorage.setItem('password', this.pass) ;
  }
}
