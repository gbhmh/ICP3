import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// export class AppComponent {
// }

export class AppComponent implements OnInit {
  user: string;
  pass: string;
  title = 'Food Calories'
  public loc5: any;
  public value5: any;
  public value6: any;
  public value3: any;
  constructor() { }

  ngOnInit() {
  }
  Show() {

    this.loc5 = {
      user: this.user,
      pass: this.pass
    };
    this.value5 = (localStorage.getItem('username'));
    this.value6 = (localStorage.getItem('password'));
    if (this.user === this.value5 && this.pass === this.value6) {

     }
    // localStorage.setItem( key: 'loc');
    // localStorage.clear();
    // localStorage.setItem('credentials', JSON.stringify(this.loc));
  }
}
